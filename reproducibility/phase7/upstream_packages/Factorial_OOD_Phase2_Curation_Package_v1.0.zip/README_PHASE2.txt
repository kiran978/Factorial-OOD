FACTORIAL-OOD - Phase 2 Curation Package v1.0
Date: 2026-08-31

Purpose
Chemical identity, biological-context and Tox21 label curation following Phase 1 Gate A. No predictive model, feature selection, OOD threshold fitting, endpoint-performance selection, or factorial-cell result inspection was performed.

Frozen decisions
- Immutable modeling identity: Phase-1 curated parent_compound_id, exported as compound_id.
- Route B retained because all-three-context completeness is 41.2%, below the prespecified 70% Route-A threshold.
- Parent-endpoint conflicts remain NA/inconclusive.
- Repeated parent-context source rows are preserved and will be collapsed by featurewise median before modeling.
- Stereochemistry in the frozen parent SMILES is retained; no outcome-informed chemical collapsing was introduced.

Key counts
- 2,017 immutable parent compounds.
- 4,142 integrated source rows -> 4,021 unique parent-context modeling rows.
- 116 duplicate parent-context keys: 111 with two source rows and 5 with three.
- MCF7: 1,674 parents; U2OS: 1,173; HepRG: 1,174.
- 41 Tox21 endpoints; 33 parent-endpoint conflicts set to NA.
- 40/41 endpoints pass the preliminary >=50 active and >=100 inactive class-count screen.
- TOX21_AR_BLA_Agonist_ratio has 44 active parents and is class-support-limited before Phase 3.

QC/provenance
- All 4,021 parent-context rows have direct source/sample metadata matches.
- MCF7: direct File S5 qc_flag audit. Every integrated source row maps to at least one QC-OK record; upstream DE filtering uses qc_flag == OK.
- U2OS: source analysis script filters Sample_key.rds to qc_flag == OK; the checksum-locked RDS was not independently parsed in the Python Phase 2 environment.
- HepaRG: GEO and processing provenance are directly traceable; no separate per-row qc_flag table was supplied.

Phase 3 boundary
Bemis-Murcko scaffold diversity, endpoint tiering, chemical/biological OOD cell population, and factorial support are not adjudicated in Phase 2. They must be evaluated prospectively in Phase 3 using the frozen curation outputs.
