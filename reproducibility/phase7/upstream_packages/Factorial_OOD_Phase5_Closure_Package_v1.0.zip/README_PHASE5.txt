FACTORIAL-OOD — Phase 5 Leakage-Safe Feature Construction
Protocol v0.2
Status: PASS

This package closes Phase 5. It contains the parent-level Morgan and physicochemical feature definitions, training-scope descriptor scaler registry, fusion-row manifest, HTTr PCA scope/checksum registries, local Phase5B leakage tests, independent validation tests, and final completion decision.

The complete 25 PCA transformer NPZ objects remain on the user's local machine under Phase5B_Output/transformers. Their SHA-256 hashes are frozen in P5_08_HTTr_transformer_checksum_registry.csv. The 77 MiB Phase5B upload package has SHA-256 699dc521e0be0906fbc9b270ba08106874a0aeeaf96b2936453d473af4eb8894.

No Tox21 endpoint values or predictive performance metrics were used to construct features or transformations.
