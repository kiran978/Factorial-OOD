FACTORIAL-OOD - Phase 3 Endpoint and Factorial-Cell Feasibility Audit

Status: COMPLETE
Gate B: PASS - FOCUSED BENCHMARK
Primary endpoints: 8
Secondary: 28
Exploratory: 4
Excluded: 1

Important: Protocol Amendment v0.2 is prospective and was generated before any predictive modeling.
The Phase 4 split package must reuse the nominated outer manifest and run leakage tests before modeling.
