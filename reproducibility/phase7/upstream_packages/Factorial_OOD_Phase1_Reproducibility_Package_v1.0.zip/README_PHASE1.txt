FACTORIAL OOD PROJECT — PHASE 1 REPRODUCIBILITY PACKAGE
Version: 1.0
Date: 31 August 2026

Purpose
-------
This package contains the complete machine-readable outputs and scripts for Phase 1: data inventory, provenance, compound-identity, label, duplicate/leakage, missingness and multi-context audit. It does NOT contain the ~420 MB raw source files. The raw files are locked by SHA-256 in SHA256SUMS_PHASE1.txt and P1_01_source_inventory_enriched.csv.

Frozen Phase 1 decisions
------------------------
- Matrix: 4,142 rows × 17,029 columns.
- Feature families: 4 metadata, 163 MACCS, 41 Tox21 endpoints, 16,821 HTTr variables.
- Parent identity: RDKit FragmentParent -> Uncharger -> canonical isomeric SMILES.
- 2,061 matrix DTXSIDs collapse to 2,017 curated parents.
- 43 parent collision groups involve 87 DTXSIDs.
- 33 parent × endpoint conflicts affect 18 parents and 18 endpoints; these labels are set to missing/inconclusive.
- 40/41 endpoints pass the preliminary class-count rule; TOX21_AR_BLA_Agonist_ratio fails (44 active parents).
- All-three-context completeness: 831/2,017 = 41.2%; therefore Route B is selected.
- 67 DTXSID × context duplicate keys exist; after parent collapse, 116 parent × context keys contain repeats.
- Integrated HTTr, MACCS and metadata columns have zero missing cells; Tox21 endpoint labels contain missing values.
- Gate A: PASS WITH RECORDED CONDITIONS.

Important
---------
No predictive model, feature selection, split optimization or outcome-guided thresholding was performed in Phase 1.
