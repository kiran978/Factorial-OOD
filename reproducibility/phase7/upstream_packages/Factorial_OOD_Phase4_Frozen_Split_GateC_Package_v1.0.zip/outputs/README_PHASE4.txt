FACTORIAL-OOD Phase 4 — Frozen Split Package and Gate C
Protocol: v0.2, approved 2026-08-31

Primary outer split:
- Inherited unchanged from Phase 3 nominated P3_02 manifest.
- 5 grouped outer folds, parent-compound unit.
- Hash: SHA256(compound_id|canonical_parent_smiles|FACTORIAL-OOD-v0.1)[:16] mod 5.

Nested inner CV:
- 4 grouped inner folds inside each outer-training set.
- Assignment uses identity fields only and includes split_set + outer_fold in the hash.

Robustness splits:
- Four alternative V3 outer/inner split sets were frozen prospectively in Phase 4.
- They are robustness-only and may not replace the primary split.

Gate C: PASS
Leakage/unit tests: 23/23 PASS.
No predictive model was trained in Phase 4.
