FACTORIAL-OOD Phase 4 — Frozen Outer/Inner Split Package and Gate C
Protocol v0.2 approved by the user on 31 August 2026.

Gate C: PASS (23/23 leakage/unit tests).
No predictive model was trained during Phase 4.

Key files:
- Factorial_OOD_Phase4_GateC_Report_v1.0.docx
- outputs/P4_01_primary_outer_split_manifest_FROZEN.csv
- outputs/P4_04_nested_inner_split_manifest_FROZEN.csv
- outputs/P4_08_preprocessing_scope_registry.csv
- outputs/P4_12_leakage_unit_tests.csv
- outputs/P4_16_gateC_decision.csv
- outputs/P4_18_protocol_approval_and_freeze_record.csv
- scripts/build_phase4.py

The PRIMARY split is confirmatory and immutable. V3_ALT01–V3_ALT04 are robustness-only and may not replace it.
